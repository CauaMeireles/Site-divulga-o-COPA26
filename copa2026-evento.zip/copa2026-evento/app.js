/**
 * Copa do Mundo 2026 - Site do Evento
 * Node.js + Express + EJS
 * 
 * Para rodar localmente:
 *   npm install
 *   npm start
 * 
 * Acesse: http://localhost:3000
 */

const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Configuração do EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Servir arquivos estáticos (CSS, imagens)
app.use(express.static(path.join(__dirname, 'public')));

// ============================================================
// LINK PARA O SITE DE CADASTRO DAS SELEÇÕES
// Troque pela URL real do seu site da Vercel
// ============================================================
const URL_SELECOES = 'https://copa-do-mundo26-times.vercel.app';

// Dados do evento
const evento = {
    nome: 'Copa do Mundo FIFA 2026',
    edicao: '23ª edição',
    dataInicio: '11 de junho de 2026',
    dataFim: '19 de julho de 2026',
    paisesSedes: ['Canadá', 'México', 'Estados Unidos'],
    selecoes: 48,
    jogos: 104,
    estadios: 16,
    cidades: 16,
    mascote: 'Maple, Zayu e Clutch',
    urlSelecoes: URL_SELECOES
};

// Estádios principais com imagens
const estadios = [
    {
        nome: 'MetLife Stadium',
        cidade: 'East Rutherford, Nova Jersey',
        pais: '🇺🇸 Estados Unidos',
        capacidade: '82.500',
        destaque: 'Final da Copa',
        imagem: 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/41/MetLife_Stadium_%28September_2014%29.JPG/640px-MetLife_Stadium_%28September_2014%29.JPG'
    },
    {
        nome: 'Estádio Azteca',
        cidade: 'Cidade do México',
        pais: '🇲🇽 México',
        capacidade: '87.000',
        destaque: 'Jogo de abertura',
        imagem: 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e3/Estadio_Azteca_2015.jpg/640px-Estadio_Azteca_2015.jpg'
    },
    {
        nome: 'SoFi Stadium',
        cidade: 'Los Angeles',
        pais: '🇺🇸 Estados Unidos',
        capacidade: '70.000',
        destaque: 'Jogos eliminatórios',
        imagem: 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/20/SoFi_Stadium_-_August_2021_%2851407560596%29.jpg/640px-SoFi_Stadium_-_August_2021_%2851407560596%29.jpg'
    },
    {
        nome: 'BMO Field',
        cidade: 'Toronto',
        pais: '🇨🇦 Canadá',
        capacidade: '45.000',
        destaque: 'Jogos do grupo',
        imagem: 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/4f/BMO_Field_Toronto_FC.jpg/640px-BMO_Field_Toronto_FC.jpg'
    },
    {
        nome: 'AT&T Stadium',
        cidade: 'Arlington, Texas',
        pais: '🇺🇸 Estados Unidos',
        capacidade: '80.000',
        destaque: 'Semifinais',
        imagem: 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/fb/Cowboys_Stadium_full.jpg/640px-Cowboys_Stadium_full.jpg'
    },
    {
        nome: 'BC Place',
        cidade: 'Vancouver',
        pais: '🇨🇦 Canadá',
        capacidade: '54.500',
        destaque: 'Jogos do grupo',
        imagem: 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/21/BC_Place_aerial.jpg/640px-BC_Place_aerial.jpg'
    }
];

// Informações importantes do evento
const informacoes = [
    {
        icone: '🎟️',
        titulo: 'Ingressos',
        descricao: 'Vendas oficiais através do site da FIFA. Atenção a sites não autorizados.'
    },
    {
        icone: '✈️',
        titulo: 'Como Chegar',
        descricao: 'Voos diretos para os 3 países sede. Confira documentação e vistos necessários.'
    },
    {
        icone: '🏨',
        titulo: 'Hospedagem',
        descricao: 'Reserve com antecedência. Pacotes especiais disponíveis nas cidades-sede.'
    },
    {
        icone: '⚽',
        titulo: 'Programação',
        descricao: '104 jogos espalhados por 39 dias. Confira o calendário completo.'
    }
];

// Rota principal
app.get('/', (req, res) => {
    res.render('index', { evento, estadios, informacoes });
});

// Rota de redirect para o site de seleções
app.get('/selecoes', (req, res) => {
    res.redirect(URL_SELECOES);
});

// Tratamento de erro 404
app.use((req, res) => {
    res.status(404).render('index', { evento, estadios, informacoes });
});

app.listen(PORT, () => {
    console.log(`⚽ Servidor rodando em http://localhost:${PORT}`);
    console.log(`🏆 Copa do Mundo 2026 - Site do Evento`);
});
